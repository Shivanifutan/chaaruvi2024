<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\slider;
use App\Models\Service;
use App\Models\Serviceadd;
use App\Models\About;
use App\Models\client;
use App\Models\career;
use App\Models\Resumeupload;
use App\Models\webContact;
use App\Models\Pricing;


class webcontroller extends Controller
{
    public function index()
    {
        $abouts = About::limit(1)->get();
        $Serviceadds = Serviceadd::all();
        $sliders = slider::all();
        $serivcename= Service::all();

        
        return view('/welcome',compact('sliders' ,'Serviceadds','abouts','serivcename'));
    }

    public function about()
    {
        $serivcename= Service::all();
        $abouts = About::offset(1)->limit(1)->get();
        return view('about',compact('abouts' ,'serivcename'));
    }

    public function service()
    {
        $serivcename= Service::all();
        $Serviceadds= Serviceadd::all();
        return view('services',compact('Serviceadds','serivcename'));
    }

    public function pricing()
    {
        $serivcename= Service::all();
        $pricingdata= Pricing::all();
       
        return view('pricing',compact('serivcename','pricingdata'));
    }

    public function client()
    {
        
        $serivcename = Service::all();
        $clients= client::all();
        return view('clients',compact('serivcename','clients'));
    }

    public function career()
    {
        $serivcename = Service::all();
        $careers= career::all();
        return view('career',compact('careers','serivcename'));
    }

    public function resumeupload(Request $request)
    {
     
        $request->validate([
            'emp_name' => 'required',
            'emp_email' => 'required',
            'emp_contact' => 'required',
            'resume' => 'required',
         ]);

        
  
            $input = $request->except('_token');
         
            if($request->hasFile('resume')){
               $imgname = $request->file('resume');
                   $filename = "resume".date('Ymdhis').'.'.$imgname->extension();
                   $imgname->storeAs('document', $filename, 'public');
                
                   $input['resume']=$filename;
            } 
   
            Resumeupload::create($input);
            return redirect('career')->with('message','Record Added !');
    }

    public function contact()
    {
        $serivcename = Service::all();
       
        return view('contact',compact('serivcename'));
    }

    public function contactdata(Request $request)
    {
    

        $request->validate([
            'name' => 'required',
            'phone' => 'required',
            'email' => 'required',
            'url' => 'required',
            'message' => 'required',
         ]);

        
  
            $input = $request->except('_token');
            webContact::create($input);
            return redirect('contact')->with('message','Record Added !');
    }


    public function condition()
    {
        $serivcename = Service::all();
        return view('terms-and-condition',compact('serivcename'));
    }


    public function refund()
    {
        $serivcename = Service::all();
        return view('refund-and-cancellation-policy',compact('serivcename'));
    }
    public function privacy()
    {
        $serivcename = Service::all();
        return view('privacy-policy',compact('serivcename'));
    }




}
