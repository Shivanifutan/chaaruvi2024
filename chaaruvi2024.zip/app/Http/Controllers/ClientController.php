<?php

namespace App\Http\Controllers;

use App\Models\client;
use Illuminate\Http\Request;

class ClientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $clients = client::all();
      
        return view('admin.client_entry',compact('clients'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'cname' => 'required',
            'cimg' => 'nullable|image',
            'pro_name' => 'required',
            'msg' => 'nullable',
         ]);

        
  
            $input = $request->except('_token');
         
            if($request->hasFile('cimg')){
               $imgname = $request->file('cimg');
                   $filename = "cimg".date('Ymdhis').'.'.$imgname->extension();
                   $imgname->storeAs('document', $filename, 'public');
                
                   $input['cimg']=$filename;
            } 
   
            client::create($input);
            return redirect('client_entry')->with('message','Record Added !');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\client  $client
     * @return \Illuminate\Http\Response
     */
    public function show(client $client)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\client  $client
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $clients = client::all();
        $editData = client::where('id',$id)->get();
        // dd($editData);
        return view('admin.client_entry',compact('editData','clients'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\client  $client
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $client)
    {
        $request->validate([
            'cname' => 'required',
            'cimg' => 'nullable|image',
            'pro_name' => 'required',
            'msg' => 'nullable',
        ]);   
    
       
        if($request->hasFile('cimg')){
            $img=client::where('id',$client)->pluck('cimg')->first();
            unlink(storage_path('app/public/document/'.$img));
            $imgname = $request->file('cimg');
            $filename = "cimg".date('Ymdhis').'.'.$imgname->extension();
            $imgname->storeAs('document', $filename, 'public');
        } else{
            $filename=$request['old_img'];
        }
        client::where('id',$client)->update(array_merge($request->except('_token','_method','old_img','cimg'),['cimg'=>$filename]));
        return redirect()->route('client_entry.index')->with('message','Record Updated !');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\client  $client
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $client = client::find($id)->delete();
        return redirect()->back()->with('message','Record Deleted !');
    }
}
