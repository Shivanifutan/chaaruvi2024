<?php

namespace App\Http\Controllers;

use App\Models\About;
use Illuminate\Http\Request;

class AboutController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $abouts = About::all();
      
        return view('admin.about_entry',compact('abouts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'about_image' => 'required',
            'heading' => 'required',
            'pdesc' => 'required',
         ]);
         

        
  
            $input = $request->except('_token');
         
            if($request->hasFile('about_image')){
               $imgname = $request->file('about_image');
                   $filename = "about_image".date('Ymdhis').'.'.$imgname->extension();
                   $imgname->storeAs('document', $filename, 'public');
                
                   $input['about_image']=$filename;
            } 
   
            About::create($input);
            return redirect('about_entry')->with('message','Record Added !');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\About  $about
     * @return \Illuminate\Http\Response
     */
    public function show(About $about)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\About  $about
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $abouts = About::all();  
        $editData = About::where('id',$id)->get();
        return view('admin.about_entry',compact('editData','abouts'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\About  $about
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $about)
    {
        $request->validate([
        'heading' => 'nullable',
        'about_image' => 'nullable|image',
        'pdesc' => 'nullable|string',
    
    ]);   

   
    if($request->hasFile('about_image')){
        $img=About::where('id',$about)->pluck('about_image')->first();
        unlink(storage_path('app/public/document/'.$img));
        $imgname = $request->file('about_image');
        $filename = "about_image".date('Ymdhis').'.'.$imgname->extension();
        $imgname->storeAs('document', $filename, 'public');
    } else{
        $filename=$request['old_img'];
    }
    About::where('id',$about)->update(array_merge($request->except('_token','_method','old_img','about_image'),['about_image'=>$filename]));
    return redirect()->route('about_entry.index')->with('message','Record Updated !');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\About  $about
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $abouts = About::find($id)->delete();
        return redirect()->back()->with('message','Record Deleted !');
    }
}
