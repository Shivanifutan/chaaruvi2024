<?php

namespace App\Http\Controllers;

use App\Models\Pricing;
use App\Models\plan;
use App\Models\Service;
use Illuminate\Http\Request;

class PricingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $plans= plan::all();
        $serivces= Service::all();
        $pricings = Pricing::all();
        return view('admin.pricing_master',compact('plans','serivces','pricings'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'plan_id' => 'required',
            'service_id' => 'required',
            'price' => 'required',
            'pdesc' => 'required',
         ]);

        
  
            $input = $request->except('_token');
        
            Pricing::create($input);
            return redirect('pricing_master')->with('message','Record Added !');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Pricing  $pricing
     * @return \Illuminate\Http\Response
     */
    public function show(Pricing $pricing)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Pricing  $pricing
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
    
        $plans= plan::all();
        $serivces= Service::all();
        $pricings = Pricing::all();  
        $editData = Pricing::where('id',$id)->get();
   
        return view('admin.pricing_master',compact('editData','pricings','plans','serivces'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Pricing  $pricing
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $pricing)
    {
        $request->validate(['plan_id'=>'required',
        'service_id' => 'nullable',
        'price' => 'required|string',
        'pdesc' => 'nullable|string',
    ]);   
        Pricing::where('id',$pricing)->update($request->except('_token','_method'));
        return redirect()->route('pricing_master.index')->with('message','Record Updated !');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Pricing  $pricing
     * @return \Illuminate\Http\Response
     */
    public function destroy($pricing)
    {
        $pricings = Pricing::find($pricing)->delete();
        return redirect()->back()->with('message','Record Deleted !');
    }
}
