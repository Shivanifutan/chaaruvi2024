<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Exception;

class Authcontroller extends Controller
{
    public function login(Request $request){
        $request->validate([
            'email'=>'required|email|exists:users,email',
            'password'=>'required|max:12'
        ]);
        try {
            if(Auth::attempt(['email' => $request['email'], 'password' => $request['password'] ])){
                return redirect()->route('dashboard')->with('success','Login Successfully');
            }else{
                return back()->with('error','Your Credential Not Match');
            }
        } catch (\Exception $ex) {
            return $ex;
        }
    }

    public function logout(){
        Auth::logout();
        session()->flush();
        return redirect()->route('login')->with('success','Logout Successfully');
    }
}
