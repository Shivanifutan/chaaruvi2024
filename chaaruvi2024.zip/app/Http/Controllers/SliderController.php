<?php

namespace App\Http\Controllers;

use App\Models\slider;
use Illuminate\Http\Request;

class SliderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $sliders = slider::all();
      
        return view('admin.company',compact('sliders'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'image' => 'required',
            'title' => 'required',
         ]);

        
  
            $input = $request->except('_token');
         
            if($request->hasFile('image')){
                $imgname = $request->file('image');
                   $filename = "image".date('Ymdhis').'.'.$imgname->extension();
                   $imgname->storeAs('document', $filename, 'public');
                
                   $input['image']=$filename;
            } 
         
            slider::create($input);
            return redirect('company')->with('message','Record Added !');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function show(slider $slider)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $sliders = slider::all();  
        $editData = slider::where('id',$id)->get();
        return view('admin.company',compact('editData','sliders'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'image' => 'required',
            'title' => 'required',

         ]);

         $input = $request->all();

         if($request->hasFile('image')){
            $imgname = $request->file('image');
                $filename = "image".date('Ymdhis').'.'.$imgname->extension();
                $imgname->storeAs('document', $filename, 'public');
             
                $input['image']=$filename;
         } 

         
         unset($input['_token']);
         unset($input['_method']);
         slider::where('id',$id)->update($input);
     
         return redirect()->back()->with('message','Record Updated !');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\slider  $slider
     * @return \Illuminate\Http\Response
     */
    public function destroy(slider $slider)
    {
        //
    }
}
