<?php

namespace App\Http\Controllers;

use App\Models\Serviceadd;
use App\Models\Service;
use Illuminate\Http\Request;

class ServiceaddController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $serivces = Service::all();
        $serviceadds= Serviceadd::all();
        return view('admin.service_entry',compact('serivces','serviceadds'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'plan_id' => 'required',
            'ser_image' => 'required',
            'heading' => 'required',
            'pdesc' => 'required',
         ]);

        
  
            
         $input = $request->except('_token');
         
         if($request->hasFile('ser_image')){
            $imgname = $request->file('ser_image');
                $filename = "ser_image".date('Ymdhis').'.'.$imgname->extension();
                $imgname->storeAs('document', $filename, 'public');
             
                $input['ser_image']=$filename;
         } 
        
            serviceadd::create($input);
            return redirect('service_entry')->with('message','Record Added !');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Serviceadd  $serviceadd
     * @return \Illuminate\Http\Response
     */
    public function show(Serviceadd $serviceadd)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Serviceadd  $serviceadd
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
     
        $serivces = Service::all();
        $serviceadds= Serviceadd::all();
        $editData = Serviceadd::where('id',$id)->get();
        return view('admin.service_entry',compact('editData','serivces','serviceadds'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Serviceadd  $serviceadd
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $serviceadd)
    {
        $request->validate([
            'plan_id' => 'required',
            'ser_image' => 'required',
            'heading' => 'required',
            'pdesc' => 'required',
        
        ]);   
    
       
        if($request->hasFile('ser_image')){
            $img=Serviceadd::where('id',$serviceadd)->pluck('ser_image')->first();
            // unlink(storage_path('app/public/document/'.$img));
            $imgname = $request->file('ser_image');
            $filename = "ser_image".date('Ymdhis').'.'.$imgname->extension();
            $imgname->storeAs('document', $filename, 'public');
        } else{
            $filename=$request['old_img'];
        }
        Serviceadd::where('id',$serviceadd)->update(array_merge($request->except('_token','_method','old_img','ser_image'),['ser_image'=>$filename]));
        return redirect()->route('service_entry.index')->with('message','Record Updated !');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Serviceadd  $serviceadd
     * @return \Illuminate\Http\Response
     */
    public function destroy($serviceadd)
    {
        $serviceadds = Serviceadd::find($serviceadd)->delete();
        return redirect()->back()->with('message','Record Deleted !');
    }
}
