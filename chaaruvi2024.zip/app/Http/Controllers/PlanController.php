<?php

namespace App\Http\Controllers;

use App\Models\plan;
use Illuminate\Http\Request;

class PlanController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $plans = plan::all();
        return view('admin.plan_master',compact('plans'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'plan_name' => 'required',
         ]);
          $input = $request->except('_token');
          plan::create($input);
         return redirect('plan_master')->with('message','Record Added !');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function show(plan $plan)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $plans = plan::all();  
        $editData = plan::where('id',$id)->get();
        return view('admin.plan_master',compact('editData','plans'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $plan)
    {
        $request->validate(['plan_name'=>'required']);   
        plan::where('id',$plan)->update($request->except('_token','_method'));
        return redirect()->route('plan_master.index')->with('message','Record Updated !');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\plan  $plan
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $plans = plan::find($id)->delete();
        return redirect()->back()->with('message','Record Deleted !');
    }
}
