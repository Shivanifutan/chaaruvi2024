<?php
    use Illuminate\Support\Facades\DB;
?>
<?php
    //Array data show in pre tag
    if(!function_exists("p"))
    {
        function p($data)
        {
            echo "<pre>";
            print_r($data);
            die;
        }
    }

    if(!function_exists("getval"))
    {
        function getval($table,$keyname,$id,$value){
            $data=DB::table($table)->where($keyname,$id)->pluck($value)->first();
            return $data;
        }
    }
?>